import board
import digitalio
from gpiozero import Button, LED
import adafruit_character_lcd.character_lcd as characterlcd
import Property as p
import serial
import time
import mido
import sys

thinkingPin = 3
print("setting up GPIO...")
thinkingLED = LED(thinkingPin)
button = Button(21)
thinkingLED.off()

print("setting up LCD...")

lcd_rs = digitalio.DigitalInOut(board.D26)
lcd_en = digitalio.DigitalInOut(board.D19)
lcd_d7 = digitalio.DigitalInOut(board.D27)
lcd_d6 = digitalio.DigitalInOut(board.D22)
lcd_d5 = digitalio.DigitalInOut(board.D24)
lcd_d4 = digitalio.DigitalInOut(board.D25)

lcd_columns = 20
lcd_rows = 4

lcd = characterlcd.Character_LCD_Mono(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, lcd_columns, lcd_rows)
lcd.clear()

lcd.message=("PICKER")

lcd.cursor_position(0,1)
lcd.message=("STATUS")

lcd.cursor_position(0,2)
lcd.message=("Arduino connection")
print("connecting to Arduino")
for attempt in range(0,11):
    try:
        ser = serial.Serial('/dev/ttyUSB0',9600,timeout=2)
        break
    except:
        lcd.cursor_position(0,3)
        lcd.message=(str("Attempt "+str(attempt)+"/10     "))
        time.sleep(5)
if attempt == 10:
    lcd.cursor_position(0,3)
    lcd.message=("Failed              ")
    sys.exit(0)

#PICKER CODE STARTS HERE

options = ["a","b","c"]

lcd.cursor_position(0,3)
lcd.message=(""" Hold 'A' when done """)

message = "0,8,0,0" #default message goes to first parameter of first bank
t1 = time.time()
buffer = 4

choice = 0

options.append("+Add new+")

optionsNum = len(options)

while True:
    a = message.split(',')

    if button.is_pressed:
        choice = options[choice]
        sys.exit(0)
    
    if len(a) == 4:
        thinkingLED.on()
        try:
            index = int(a[1])
            value = a[2]
        except:
            index = 0
            value = controlPanel[0]

        # stuff from encoders (only 1, 2, and 3 for now)
        if index > 7 and index < 11:
            if buffer > 2:
                buffer = 0
                index = index-8
                if value == "+":
                    if choice < optionsNum-1:
                        choice = choice+1
                elif value == "-":
                    if choice > 0:
                        choice = choice-1
                        
                lcd.cursor_position(0,2)
                pageNum = str(choice+1)+"/"+str(optionsNum)
                msg = options[choice]
                while len(msg) < (20-len(pageNum)):
                    msg = msg+" "
                msg = msg+pageNum
                lcd.message=(msg)

            else:
                buffer = buffer+1
 
        #elif index < 8:
            
    thinkingLED.off()

    message = str(ser.readline())
