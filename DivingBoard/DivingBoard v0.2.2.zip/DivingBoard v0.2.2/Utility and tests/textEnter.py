import board
import digitalio
from gpiozero import Button, LED
import adafruit_character_lcd.character_lcd as characterlcd
import Property as p
import serial
import time
import mido
import sys

thinkingPin = 3
print("setting up GPIO...")
thinkingLED = LED(thinkingPin)
button = Button(21)
thinkingLED.off()

print("setting up LCD...")

lcd_rs = digitalio.DigitalInOut(board.D26)
lcd_en = digitalio.DigitalInOut(board.D19)
lcd_d7 = digitalio.DigitalInOut(board.D27)
lcd_d6 = digitalio.DigitalInOut(board.D22)
lcd_d5 = digitalio.DigitalInOut(board.D24)
lcd_d4 = digitalio.DigitalInOut(board.D25)

lcd_columns = 20
lcd_rows = 4

lcd = characterlcd.Character_LCD_Mono(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, lcd_columns, lcd_rows)
lcd.clear()

lcd.message=("ENTER TEXT")

lcd.cursor_position(0,1)
lcd.message=("STATUS")

lcd.cursor_position(0,2)
lcd.message=("Arduino connection")
print("connecting to Arduino")
for attempt in range(0,11):
    try:
        ser = serial.Serial('/dev/ttyUSB0',9600,timeout=2)
        break
    except:
        lcd.cursor_position(0,3)
        lcd.message=(str("Attempt "+str(attempt)+"/10     "))
        time.sleep(5)
if attempt == 10:
    lcd.cursor_position(0,3)
    lcd.message=("Failed              ")
    sys.exit(0)

#TEXT ENTER CODE STARTS HERE

lcd.clear()

lcd.message=("""Use encoders to pick
letters             

Hold FUNC when done """)

chars = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

message = "0,0,0,0" #default message goes to first parameter of first bank
t1 = time.time()
buffer = 4

controlPanel=[0,0,0,0]

lcd.cursor_position(0,2)
lcd.message=(str("      > "+chars[controlPanel[0]]+chars[controlPanel[1]]+chars[controlPanel[2]]+chars[controlPanel[3]]+" <      "))

while True:
    a = message.split(',')

    if button.is_pressed:
        lcd.clear()
        word = str(chars[controlPanel[0]]+chars[controlPanel[1]]+chars[controlPanel[2]]+chars[controlPanel[3]])
        print(word)
        lcd.message=(word)
        sys.exit(0)
    
    if len(a) == 4:
        thinkingLED.on()
        try:
            index = int(a[1])
            value = a[2]
        except:
            index = 0
            value = controlPanel[0]

        # stuff from encoders (only 1, 2, and 3 for now)
        if index > 7 and index < 11:
            if buffer > 2:
                buffer = 0
                index = index-8
                if value == "+":
                    if controlPanel[index] == len(chars)-1:
                       controlPanel[index] = 0
                    else:
                        controlPanel[index] = controlPanel[index]+1
                elif value == "-":
                    if controlPanel[index] == 0:
                       controlPanel[index] = len(chars)-1
                    else:
                        controlPanel[index] = controlPanel[index]-1
                        
                #print(chars[controlPanel[0]],chars[controlPanel[1]],chars[controlPanel[2]],chars[controlPanel[3]])
                lcd.cursor_position(0,2)
                lcd.message=(str("      > "+chars[controlPanel[0]]+chars[controlPanel[1]]+chars[controlPanel[2]]+chars[controlPanel[3]]+" <      "))

            else:
                buffer = buffer+1
 
        #elif index < 8:
            
    thinkingLED.off()

    message = str(ser.readline())
