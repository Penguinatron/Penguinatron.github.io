exec(open("adder.py").read())
print("test")
