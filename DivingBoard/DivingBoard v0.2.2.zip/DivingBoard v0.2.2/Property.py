import mido
import re

class Property:
    def __init__(self,dispName="X",addr="0",min=0,max=0,readIn=0,dispMode="1"):
        try:
            self.name = dispName
            a = addr.split(".")
            a.pop(len(a)-1)
            self.address = a
            self.minimum = int(min)
            self.maximum = int(max)
            self.ReadInIndex = int(readIn)
            if len(dispMode) == 1:
                self.displayMode = re.sub('\n', '', dispMode)
            else:
                self.displayMode = dispMode.split(' ')
            self.current = self.maximum
        except:
            self.name = "X"
            self.address = []
            self.minimum = 0
            self.maximum = 0
            self.ReadInIndex = 0
            self.displayMode = 1
            self.current = 0
        return None

    def displayValue(self,value): #return string version of the current value for screening. This function will contain extra maths or switch statements for some properties (-63 - +63 things, waveshapes, etc.)
        if self.displayMode == "1":
            return str(value)
        elif self.displayMode ==  "2":
            return str((value)-63)
        elif self.displayMode == "3":
            return str(10*(value)-640)
        else:
            listItem = value - self.minimum
            return(self.displayMode[listItem])

    """def set(self,data): #Set value of parameter, within min and max.
        if data >= self.minimum and data <= self.maximum:
            self.current = data
            return True
        else:
            return False"""
    
    """def sendMidi(self,port):
        endcap = "00 F7"
        numberA = format(self.current, 'x')
        if len(numberA) == 1:
            numberA = '0'+numberA
        msg1 = self.address + numberA + ' 00 F7'
        msg = mido.Message.from_hex(msg1)
        port.send(msg)"""
"""
file = open("params.csv","r")
data = file.readlines()
file.close()

parameters = []

for count in range (1,len(data)-1):
    thing = data[count]
    thingy = thing.strip("\n")
    things = thingy.split(',')
    if things[0] == "An":
        param = Property(things[3],things[4],things[5],things[6],things[7],things[8])
        parameters.append(param)

for count in range(0,len(parameters)):
    print(parameters[count].name)
"""
