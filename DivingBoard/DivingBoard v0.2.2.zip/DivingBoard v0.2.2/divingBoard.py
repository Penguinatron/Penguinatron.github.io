print("""
0.2.2: Numerous little bits and bobs
    - All encoder buttons are now accounted for in software
        + Holding down button F now quits the programme
    - The programme now reads from jdxi.dbd rather than params.csv
        + The actual data formatting and file contents are similar
            * we lose the final line of explanation text, which has migrated to the README
            * The first line will now hold the synth's MIDI name (as given by the Pi), to allow future versions to detect the connected instrument and automatically use the correct DBD file
        + Name of file reflects the synth's name, and the DBD file extension is so that future scripts can look for all DBD files in the directory to establish the available synth files
    - The programme now exits using a 'break' statement rather than 'sys.exit(0)', allowing the main menu to take over afterwards (using the dodgy 'exec()' strategy)
""")

print("DivingBoard v0.2.2 loading")
print("importing libraries...")

#update these if required for running without connections (default is True,False,True)
screenConnected = True
keyboardControl = False
synthConnected = True
thinkingPin = 3

if keyboardControl == True:
    print("\nrunning with keyboard control- Arduino input is ignored\n")
if synthConnected == False:
    print("\nrunning without synth connected\n")

import board
import digitalio
import gpiozero
import adafruit_character_lcd.character_lcd as characterlcd
import Property as p
import serial
import time
import mido
import sys

buttonA = gpiozero.Button(5)
buttonB = gpiozero.Button(6)
buttonC = gpiozero.Button(13)
buttonF = gpiozero.Button(12)

print("setting up Activity LED...")
thinkingLED = gpiozero.LED(thinkingPin)
thinkingLED.off()

print("setting up LCD...")

lcd_rs = digitalio.DigitalInOut(board.D26)
lcd_en = digitalio.DigitalInOut(board.D19)
lcd_d7 = digitalio.DigitalInOut(board.D27)
lcd_d6 = digitalio.DigitalInOut(board.D22)
lcd_d5 = digitalio.DigitalInOut(board.D24)
lcd_d4 = digitalio.DigitalInOut(board.D25)

lcd_columns = 20
lcd_rows = 4

lcd = characterlcd.Character_LCD_Mono(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, lcd_columns, lcd_rows)
lcd.clear()

lcd.message=("DivingBoard v0.2.2")
time.sleep(1)

lcd.cursor_position(0,1)
lcd.message=("STATUS")

def printSynth(synth):
    print(synth[0],":")
    for w in range(1,len(synth)):
        print(synth[w][0])
        for x in range(1,len(synth[w])):
            print("---",synth[w][x][0])
            for y in range(1,len(synth[w][x])):
                print("------",synth[w][x][y][0])
                for z in range(1,len(synth[w][x][y])):
                    print("---------",synth[w][x][y][z].name)
    print()
def displayFormat(params):
    displayLines = []

    # If there are fewer parameters than knobs, insert placeholders to make this obvious
    for a in range(len(params),8):
        params.append(".")

    #display code
    for count in range(0,2):
        total = 0
        for a in range(0,4):
            if count == 1:
                total = total+len(params[a+4])
            else:
                total = total+len(params[a])

        missing = 20-total
        if missing < 0:
            print("WARNING: parameter labels are too long and can't be displayed fully")
            for a in range(0,len(params)):
                if len(params[a]) > 4:
                    params[a] = params[a][0]+params[a][1]+params[a][2]+params[a][3]
            total = 0
            for a in range(0,len(params)):
                total = total+len(params[a])

            missing = 20-total

        gap = int(missing/3)

        if count == 0:
            displayLines.append(params[0]+" "*gap+params[1]+" "*gap+params[2]+" "*gap+params[3])
        else:
            displayLines.append(params[4]+" "*gap+params[5]+" "*gap+params[6]+" "*gap+params[7])
    return displayLines

lcd.cursor_position(0,2)
lcd.message=("Synth data")
print("importing synth data")

#read data from file into list of lines
file = open("jdxi.dbd","r")
data = file.readlines()
file.close()

#remove non-data lines
a = data.pop(0)
b = a.strip('\n').split(',')
#create 'empty' data structure
synth = []
synth.append(b[0])

a = 0

for a in range(0,len(data)):
    #prepare next line of params data
    line = data[a].strip('\n').split(',')
    #print(line)
    #lcd.message=(str(line))

    engineFound = False
    
    #look for engine in list of engines
    for a in range(1,len(synth)):
        if synth[a][0] == line[0]:
            #print("Engine found!")
            engineFound = True
            break
    if engineFound == False:
        synth.append([line[0]])
        a = a+1
        #print("created engine",line[0])
        lcd.cursor_position(0,3)
        lcd.message=(str("Engine "+line[0]))
        engineFound = True

    partialFound = False
    b=0
    #look for partial in engine
    for b in range(1,len(synth[a])):
        if synth[a][b][0] == line[1]:
            #print("Partial found!")
            partialFound = True
            break
    if partialFound == False:
        synth[a].append([line[1]])
        b = b+1
        #print("created partial",line[1])
        lcd.cursor_position(0,3)
        lcd.message=(str("Partial "+line[1]))

    sectionFound = False
    c=0
    #look for section in partial
    for c in range(1,len(synth[a][b])):
        if synth[a][b][c][0] == line[2]:
            #print("Section found!")
            sectionFound = True
            break
    if sectionFound == False:
        synth[a][b].append([line[2]])
        c = c+1
        #print("created section",line[2])
        lcd.cursor_position(0,3)
        lcd.message=(str("Section "+line[2]))

    parameterFound = False
    d=0
    #look for parameter in section
    for d in range(1,len(synth[a][b][c])):
        if synth[a][b][c][d].name == line[3]:
            #print("ERROR: Duplicate parameter detected")
            lcd.cursor_position(0,3)
            lcd.message=(str("Duplicate: '"+param.name+"'  "))
            time.sleep(2)
            parameterFound = True
            break
    if parameterFound == False:
        param = p.Property(line[3],line[4],line[5],line[6],line[7],line[8])
        synth[a][b][c].append(param)
        d = d+1
        #print("created parameter",param.name)
        lcd.cursor_position(0,3)
        lcd.message=(str("Parameter "+param.name))

#print()
#time.sleep(2)
#printSynth(synth)

lcd.cursor_position(0,2)
lcd.message=("Arduino connection")
print("connecting to Arduino")
if keyboardControl == False:
    for attempt in range(0,11):
        try:
            ser = serial.Serial('/dev/ttyUSB0',9600,timeout=2)
            break
        except:
            lcd.cursor_position(0,3)
            lcd.message=(str("Attempt "+str(attempt)+"/10     "))
            time.sleep(5)
    if attempt == 10:
        lcd.cursor_position(0,3)
        lcd.message=("Failed              ")
        sys.exit(0)

lcd.cursor_position(0,2)
lcd.message=("Synth connection   ")
print("connecting to synth")

if synthConnected == True:
    for attempt in range(0,11):
        try:
            thinkingLED.on()
            #mido.get_output_names()
            portname = "JD-Xi:JD-Xi MIDI 1 24:0"
            outport = mido.open_output(portname)
            inport = mido.open_input(portname)
            thinkingLED.off()
            break
        except:
            lcd.cursor_position(0,3)
            lcd.message=(str("Attempt "+str(attempt)+"/10      "))
            print(str("Attempt "+str(attempt)+"/10      "))
            time.sleep(5)
    if attempt == 10:
        lcd.cursor_position(0,3)
        lcd.message=("Failed              ")
        print("failed")
        sys.exit(0)

lcd.cursor_position(0,3)
lcd.message=("Control panel       ")
print("Setting up control panel")


controlPanel = [0,0,0,0,0,0,0,0,2,1,1,1,1,0,0,0,0,0]
#control panel = A0,A1,A2,A3,A4,A5,A6,A7,e0,e1,e2,e3,e4,b0,b1,b2,b3,b4
#where A is an analogue input, e is an encoder input, and b is a button input.

message = "0,8,-,0" #default message goes to first parameter of first bank
t1 = time.time()
buffer = 4
print("ready!")

if keyboardControl == True:
    print("""\ninput message formatting:
control index,value
EG for a potentiometer, '0,512' would set the first knob to halfway.
EG for an encoder, '8,+' would move forwards one click of the 'engine' control, ie from An>A>Filter to D1>A>Filter\n""")

while True:

    # In the final version, the incoming message will be from the arduino- research is needed into setting up the ports and finding the way to respond quickest.
    a = message.split(',')

    if buttonF.is_pressed:
        lcd.cursor_position(0,2)
        lcd.message=("Exiting...")
        buttonF.wait_for_release()
        lcd.clear()
        #sys.exit(0)
        buttonA.close()
        buttonB.close()
        buttonC.close()
        buttonF.close()
        thinkingLED.close()
        break
    
    """if time.time() - t1 > 0.1:
            message = str(param.displayValue(controlPanel[index-1]))
            #print(message)
            while len(message) < 20:
                message = message+" "
            lcd.cursor_position(0,2)
            lcd.message=(message)
            t1 = time.time()"""
    
    if len(a) == 4:
        thinkingLED.on()
        try:
            index = int(a[1])
            value = a[2]
        except:
            index = 0
            value = controlPanel[0]

        # stuff from encoders (only 1, 2, and 3 for now)
        if index > 7 and index < 11:
            if keyboardControl == True:
                buffer = 5
            if buffer > 2:
                buffer = 0

                if value == '-':
                    newVal = controlPanel[index]-1
                elif value == '+':
                    newVal = controlPanel[index]+1
                else:
                    print("wot")
                    newVal = controlPanel[index]
                
                #switch banks
                #stop value going below 1
                if newVal < 1:
                    newVal = 1
                engineCount = len(synth)-1

                oldVal = controlPanel[index]
                
                #stop value going above number of engines
                if index == 8 and newVal > engineCount:
                    newVal = engineCount
                #
                controlPanel[index] = newVal
                partialCount = len(synth[controlPanel[8]])-1
                if partialCount < controlPanel[9]:
                    controlPanel[9] = partialCount
                if index == 9 and newVal > partialCount:
                    newVal = partialCount
                controlPanel[index] = newVal
                sectionCount = len(synth[controlPanel[8]][controlPanel[9]])-1
                if sectionCount < controlPanel[10]:
                    controlPanel[10] = sectionCount
                if index == 10 and newVal > sectionCount:
                    newVal = sectionCount

                controlPanel[index] = newVal
                if oldVal != newVal:
                    # Get list of currently selected parameter names for display
                    params = []
                    for a in range(1,len(synth[controlPanel[8]][controlPanel[9]][controlPanel[10]])):
                        params.append(synth[controlPanel[8]][controlPanel[9]][controlPanel[10]][a].name)

                    # If there are more parameters than can be shown, warn user
                    if len(params) > 8:
                        print("WARNING: More parameters exist for section than can be shown")

                    displayLines = displayFormat(params)

                    lcd.clear()
                    lcd.cursor_position(0,0)
                    lcd.message=(displayLines[0])
                    lcd.cursor_position(0,1)
                    lcd.message=(str(synth[controlPanel[8]][0]+' > '+synth[controlPanel[8]][controlPanel[9]][0]+' > '+synth[controlPanel[8]][controlPanel[9]][controlPanel[10]][0]))
                    #lcd.cursor_position(0,2)
                    #lcd.message=("---")
                    lcd.cursor_position(0,3)
                    lcd.message=(displayLines[1])
                    if screenConnected == False:
                        print(displayLines[0])
                        print(str(synth[controlPanel[8]][0]+' > '+synth[controlPanel[8]][controlPanel[9]][0]+' > '+synth[controlPanel[8]][controlPanel[9]][controlPanel[10]][0]))
                        print(displayLines[1])
            else:
                buffer = buffer+1

            # 
        elif index < 8:
            #name, address, minimum, maximum, ReadInIndex, DisplayMode, current
            index = index+1
            parameterCount = len(synth[controlPanel[8]][controlPanel[9]][controlPanel[10]])-1

            if index <= parameterCount:
                newVal = int(value)
                param = synth[controlPanel[8]][controlPanel[9]][controlPanel[10]][index]
                value = round(newVal/1024*(param.maximum-param.minimum)+param.minimum)

                msg1 = param.address[value]
                msg = mido.Message.from_hex(msg1)
                if synthConnected == True:
                    outport.send(msg)
                
                if param.displayMode not in ["1","2","3"]:
                    if value != controlPanel[index-1]:
                        message = param.displayValue(value)
                        while len(message) < 20:
                            message = message+" "
                        lcd.cursor_position(0,2)
                        lcd.message=(message)
                        if screenConnected == False:
                            print("value set to ",message)
                            
                controlPanel[index-1] = value
    else:
        lcd.cursor_position(0,2)
        lcd.message=("                    ")
    thinkingLED.off()
    if keyboardControl == True:
        message = "0,"+input(">>>")+",0"
    else:
        message = str(ser.readline())
print("quitting and returning to main menu...")
