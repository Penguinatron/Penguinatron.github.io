import sys

lcd.clear()
lcd.message=("Quitting...")
sys.exit(0)
