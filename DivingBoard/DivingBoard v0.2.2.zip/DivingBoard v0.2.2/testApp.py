import gpiozero
import sys

print("chongolong")

buttonF = gpiozero.Button(12)

while True:
    if buttonF.is_pressed == True:
        print("quitting")
        break
