#!/bin/bash
cd "/home/pi/Desktop/DivingBoard v0.1.2"
PYTHONPATH=/home/pi/.local/lib/python3.7/site-packages
python3 "/home/pi/Desktop/DivingBoard/MainMenu.py"
