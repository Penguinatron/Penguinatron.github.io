import mido
import gpiozero
import digitalio
import board
import serial
import time
import sys
import adafruit_character_lcd.character_lcd as characterlcd

print("""
Main Menu 0.3: buggy first working version
    - Use encoders to select programs to run
    - Hold button A to launch programs
        + Launching is done via the 'exec()' method, which is hacky (see explanation comment)
    - There's currently no way to exit the programme- an obvious way would be to create a 'quit.py' programme which could be launched like any other from the programme menu.
        + further to this- if something breaks, there's no error-catching code, so the DivingBoard is bricked unless you have a VNC connection to the Pi.
""")

"""
THE PROBLEM WITH THE exec() METHOD:
This main menu programme currently launches the other programmes using the 'exec(X)' method, which runs Python code block 'X'.
It's possible to run a programme within a programme like this, by specifying X as open(script.py).read(). This works, but is hacky:
    - namespace conflicts abound. This programme has a method called 'picker'. If another programme that runs has a method with the same name, things get weird. Same with variable names, etc.
    - sys.exit() calls in the programme to be run won't exit that programme and return to the main menu, it will run on the same level as the main menu programme, and exit the whole thing.
This feels like something that should be replaced at some point, but I can't be bothered right now as no-one needs to maintain this code besides me, and it's not causing any major headaches right now.
Functionality comes first, lovely code can come later in a refactoring run or ten.
"""

programs = ["divingBoard.py","adder.py","quit.py"]

exec(open("divingBoard.py").read())

def navigate(inPrograms):
    programs = inPrograms
    
    lcd.cursor_position(0,3)
    lcd.message=(""" Hold 'A' to launch """)

    message = "0,8,0,0" #default message goes to first parameter of first bank
    t1 = time.time()
    buffer = 4

    choice = 0

    programsNum = len(programs)

    while True:
        a = message.split(',')

        if buttonA.is_pressed:
            lcd.cursor_position(0,3)
            lcd.message=("Launching...        ")
            buttonA.wait_for_release()
            buttonA.close()
            buttonB.close()
            buttonC.close()
            buttonF.close()
            thinkingLED.close()
            outport.close()
            inport.close()
            
            return programs[choice]
        
        if len(a) == 4:
            thinkingLED.on()
            try:
                index = int(a[1])
                value = a[2]
            except:
                index = 0
                value = controlPanel[0]

            # stuff from encoders (only 1, 2, and 3 for now)
            if index > 7 and index < 11:
                if buffer > 2:
                    buffer = 0
                    index = index-8
                    if value == "+":
                        if choice < programsNum-1:
                            choice = choice+1
                    elif value == "-":
                        if choice > 0:
                            choice = choice-1
                            
                    lcd.cursor_position(0,2)
                    pageNum = str(choice+1)+"/"+str(programsNum)
                    msg = programs[choice]
                    while len(msg) < (20-len(pageNum)):
                        msg = msg+" "
                    msg = msg+pageNum
                    lcd.message=(msg)

                else:
                    buffer = buffer+1

        message = str(ser.readline())

while True:
    lcd_rs = digitalio.DigitalInOut(board.D26)
    lcd_en = digitalio.DigitalInOut(board.D19)
    lcd_d7 = digitalio.DigitalInOut(board.D27)
    lcd_d6 = digitalio.DigitalInOut(board.D22)
    lcd_d5 = digitalio.DigitalInOut(board.D24)
    lcd_d4 = digitalio.DigitalInOut(board.D25)

    lcd_columns = 20
    lcd_rows = 4

    lcd = characterlcd.Character_LCD_Mono(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, lcd_columns, lcd_rows)
    lcd.clear()

    lcd.message=("DivingBoard v0.2.1")

    buttonA = gpiozero.Button(5)
    buttonB = gpiozero.Button(6)
    buttonC = gpiozero.Button(13)
    buttonF = gpiozero.Button(12)

    thinkingPin = 3

    thinkingLED = gpiozero.LED(thinkingPin)
    thinkingLED.off()

    portname = "JD-Xi:JD-Xi MIDI 1 24:0"

    lcd.message=("Launcher v0.3")
    print("""Launcher v0.3""")

    lcd.cursor_position(0,2)
    lcd.message=("Arduino connection")
    print("connecting to Arduino")
    for attempt in range(0,11):
        try:
            ser = serial.Serial('/dev/ttyUSB0',9600,timeout=2)
            break
        except:
            lcd.cursor_position(0,3)
            lcd.message=(str("Attempt "+str(attempt)+"/10     "))
            time.sleep(5)
    if attempt == 10:
        lcd.cursor_position(0,3)
        lcd.message=("Failed              ")
        sys.exit(0)

    outport = mido.open_output(portname)
    inport = mido.open_input(portname)
    
    lcd.message=("""=====MAIN  MENU=====
Scroll with encoders""")
    
    toRun = navigate(programs)

    exec(open(toRun).read())
