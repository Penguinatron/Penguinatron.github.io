import mido
from gpiozero import Button, LED
import digitalio
import board
import serial
import time
import sys
import adafruit_character_lcd.character_lcd as characterlcd

buttonA = Button(5)
buttonB = Button(6)
buttonC = Button(13)
buttonF = Button(12)

thinkingPin = 3
thinkingLED = LED(thinkingPin)
thinkingLED.off()

portname = "JD-Xi:JD-Xi MIDI 1 24:0"

#JD-Xi:JD-Xi MIDI 1 24:0', 'JD-Xi:JD-Xi MIDI 2 24:1', 'JD-Xi:JD-Xi MIDI 1 24:0', 'JD-Xi:JD-Xi MIDI 2 24:1

readIn = "0" #for now, as value is unused in the main programme
dispMode = "1" #default, as we don't want the user to have to label everything individually and most things are 0-127 ranges.

def textEnter():

    lcd.message=("""
Enter new name             

Hold 'A' when done  """)

    chars = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9',' ']

    message = "0,0,0,0" #default message goes to first parameter of first bank
    t1 = time.time()
    buffer = 4

    controlPanel=[0,0,0,0]

    lcd.cursor_position(0,2)
    lcd.message=(str("      > "+chars[controlPanel[0]]+chars[controlPanel[1]]+chars[controlPanel[2]]+chars[controlPanel[3]]+" <      "))
    word = ""
    while True:
        a = message.split(',')

        if buttonA.is_pressed:
            lcd.cursor_position(0,3)
            lcd.message=("New name saved      ")
            word = str(chars[controlPanel[0]]+chars[controlPanel[1]]+chars[controlPanel[2]]+chars[controlPanel[3]])
            word = word.replace(" ","")
            buttonA.wait_for_release()
            break
        
        if len(a) == 4:
            thinkingLED.on()
            try:
                index = int(a[1])
                value = a[2]
            except:
                index = 0
                value = controlPanel[0]

            # stuff from encoders (only 1, 2, and 3 for now)
            if index > 7 and index < 12:
                if buffer > 2:
                    buffer = 0
                    index = index-8
                    if value == "+":
                        if controlPanel[index] == len(chars)-1:
                           controlPanel[index] = 0
                        else:
                            controlPanel[index] = controlPanel[index]+1
                    elif value == "-":
                        if controlPanel[index] == 0:
                           controlPanel[index] = len(chars)-1
                        else:
                            controlPanel[index] = controlPanel[index]-1
                            
                    #print(chars[controlPanel[0]],chars[controlPanel[1]],chars[controlPanel[2]],chars[controlPanel[3]])
                    lcd.cursor_position(0,2)
                    lcd.message=(str("      > "+chars[controlPanel[0]]+chars[controlPanel[1]]+chars[controlPanel[2]]+chars[controlPanel[3]]+" <      "))

                else:
                    buffer = buffer+1
     
            #elif index < 8:
                
        thinkingLED.off()

        message = str(ser.readline())
    return word

def picker(inOptions):
    options = inOptions
    
    lcd.cursor_position(0,3)
    lcd.message=(""" Hold 'A' when done """)

    message = "0,8,0,0" #default message goes to first parameter of first bank
    t1 = time.time()
    buffer = 4

    choice = 0

    controlPanel=[0,0,0,0]

    options.append("+Add new+")

    optionsNum = len(options)

    while True:
        a = message.split(',')

        if buttonA.is_pressed:
            lcd.cursor_position(0,3)
            lcd.message=("Choice registered   ")
            buttonA.wait_for_release()
            if choice == optionsNum-1:
                return textEnter()
            else:
                return options[choice]
        
        if len(a) == 4:
            thinkingLED.on()
            try:
                index = int(a[1])
                value = a[2]
            except:
                index = 0
                value = controlPanel[0]

            # stuff from encoders (only 1, 2, and 3 for now)
            if index > 7 and index < 12:
                if buffer > 2:
                    buffer = 0
                    index = index-8
                    if value == "+":
                        if choice < optionsNum-1:
                            choice = choice+1
                    elif value == "-":
                        if choice > 0:
                            choice = choice-1
                            
                    lcd.cursor_position(0,2)
                    pageNum = str(choice+1)+"/"+str(optionsNum)
                    msg = options[choice]
                    while len(msg) < (20-len(pageNum)):
                        msg = msg+" "
                    msg = msg+pageNum
                    lcd.message=(msg)

                else:
                    buffer = buffer+1
     
            #elif index < 8:
                
        thinkingLED.off()

        message = str(ser.readline())

"""
Synth,Partial,Section,Name,address,minimum,maximum,read-in index,Display Mode
"""


lcd_rs = digitalio.DigitalInOut(board.D26)
lcd_en = digitalio.DigitalInOut(board.D19)
lcd_d7 = digitalio.DigitalInOut(board.D27)
lcd_d6 = digitalio.DigitalInOut(board.D22)
lcd_d5 = digitalio.DigitalInOut(board.D24)
lcd_d4 = digitalio.DigitalInOut(board.D25)

lcd_columns = 20
lcd_rows = 4

lcd = characterlcd.Character_LCD_Mono(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, lcd_columns, lcd_rows)
lcd.clear()

lcd.message=("Adder v0.2.2")
print("""Adder v0.2.2
    - Added encoder control
        + New parameters can be added to the synth without use of the computer keyboard and mouse whatsoever
        + Step-by-step process records MIDI data, selects/creates a save name/location for the control, and then writes it to params.csv
        + Still only supports a single params.csv- no programming multiple synth control schemes YET
        + Locked-in; no way to exit the programme without going all the way through and creating a parameter (will add a 'back' button next time)
        + No failsafes- crashes are NOT handled and there's no way to recover without a mouse/keyboard.""")

lcd.cursor_position(0,2)
lcd.message=("Arduino connection")
print("connecting to Arduino")
for attempt in range(0,11):
    try:
        ser = serial.Serial('/dev/ttyUSB0',9600,timeout=2)
        break
    except:
        lcd.cursor_position(0,3)
        lcd.message=(str("Attempt "+str(attempt)+"/10     "))
        time.sleep(5)
if attempt == 10:
    lcd.cursor_position(0,3)
    lcd.message=("Failed              ")
    sys.exit(0)

lcd.cursor_position(0,1)
lcd.message=("""DON'T TOUCH KEYS OR 
CONTROLS ON SYNTH   
press Button A      """)

print("ENSURE THAT NO NOTES ARE PLAYED OR OTHER CONTROLS TOUCHED DURING THE PROCEDURE")

inport = mido.open_input(portname)

# We get the user to the parameter manipulation screen in advance of listening to the message stream to avoid other messages.

buttonA.wait_for_press()
buttonA.wait_for_release()

print("navigate to the parameter you want to learn, then press the button")

lcd.cursor_position(0,1)
lcd.message=("""Navigate to control
to learn, then press
Button A            """)

buttonA.wait_for_press()
inport.close()

buttonA.wait_for_release()

print("set the parameter to it's maximum, then press the button")# This is just so that we recieve the 'minimum' message

lcd.cursor_position(0,1)
lcd.message=("""Set control to      
maximum, then press 
Button A            """)

outport = mido.open_output(portname)
inport = mido.open_input(portname)

buttonA.wait_for_press()
inport.close()

buttonA.wait_for_release()

print("set the parameter to it's minimum, then press the button")

lcd.cursor_position(0,1)
lcd.message=("""Set control to      
MINIMUM, then press 
Button A            """)

outport = mido.open_output(portname)
inport = mido.open_input(portname)

messages = []

msg = inport.receive()
for msg in inport:
    if msg.type != 'clock':
        messages.append(msg)
    if buttonA.is_pressed:
        buttonA.wait_for_release()
        break

inport.close()

minimumMessage = [messages[len(messages)-1]] #Gets us the last message of this lot, so the minimum

print("set the parameter to it's maximum, then press the button")# This should give us a full 'sweep' of every possible message associated with this control

lcd.cursor_position(0,1)
lcd.message=("""Set control back to 
MAXIMUM, then press 
Button A            """)

outport = mido.open_output(portname)
inport = mido.open_input(portname)

messages = []

msg = inport.receive()
for msg in inport:
    if msg.type != 'clock':
        messages.append(msg)
    if buttonA.is_pressed:
        buttonA.wait_for_release()
        break

inport.close()

messageRange = minimumMessage+messages

# Now that we have the full range, time to format it!

addresses = ""# The list of messages is stored in a dot-separated list. I'm very sorry.


for count in range(0,len(messageRange)):
    a = str(messageRange[count].data).split(",")# split sysex message into a list for easy working
    a[0] = a[0].strip("(")# get rid of extra unnecessary characters which Mido adds in
    a[len(a)-1] = a[len(a)-1].strip(")")
    address = "F0 "# Add the message header which Mido omits
    for i in range(0,len(a)): # This converts each byte into hex for the main programme to use
        a[i] = (a[i].strip(" "))
        a[i] = format(int(a[i]), 'x')
        if len(a[i]) == 1:
            a[i] = "0"+a[i]
        address = address+a[i]+" "
    address = address+"F7."# Adds the message footer (and dot for the list) which Mido omits
    addresses = addresses+address# Appends the new message to the list of messages

file = open("jdxi.dbd","r")
data = file.readlines()
data.pop(0)
file.close()

options = []

for count in range(0,len(data)):
    a = data[count].split(",")
    if a[0] not in options:
        options.append(a[0])

lcd.cursor_position(0,1)
lcd.message=("Choose engine       ")
print("options:\n",options)
print("Choose a synth engine for this parameter")
synthChoice = picker(options)

options = []
for count in range(0,len(data)):
    a = data[count].split(",")
    if a[0] == synthChoice:
        if a[1] not in options:
            options.append(a[1])
lcd.cursor_position(0,1)
lcd.message=("Choose partial      ")
print("Choose an engine partial for this parameter")
partialChoice = picker(options)

options = []
for count in range(0,len(data)):
    a = data[count].split(",")
    if a[0] == synthChoice:
        if a[1] == partialChoice:
            if a[2] not in options:
                options.append(a[2])
lcd.cursor_position(0,1)
lcd.message=("Choose section      ")
print("Choose a partial section for this parameter")
sectionChoice = picker(options)


print("FOUR CHARS MAX - Enter a name for this parameter")
name = textEnter()

newEntry = synthChoice+","+partialChoice+","+sectionChoice+","+name+","+addresses+","+"0"+","+str(len(messageRange)-1)+","+readIn+","+dispMode+"\n"# Minimum and maximum are made to just be 0 and the length of the list. It may be easier in the future to move their definition to the Property object.

file = open("jdxi.dbd","a")
file.write(newEntry)
file.close()

lcd.clear()
lcd.message=(str("Control '"+name+"' in\n"+synthChoice+" > "+partialChoice+" > "+sectionChoice+"\nadded!\nPress 'A' to finish "))

buttonA.wait_for_press()
lcd.clear()
lcd.message=("""Returning to main
menu...""")
buttonA.wait_for_release()

outport.close()

buttonA.close()
buttonB.close()
buttonC.close()
buttonF.close()
thinkingLED.close()

#sys.exit(0)
