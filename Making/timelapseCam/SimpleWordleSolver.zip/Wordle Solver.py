import random

def reset():
    #Returns a list of words of length 5 from a provided text file called 'dictionary.txt', containing a list of words
    file = open("dictionary.txt","r")
    lines = file.readlines()
    file.close()

    words = []
    for count in range(0,len(lines)-1):
        word = lines[count]
        if len(word) == 6:
            words.append(word)
    return words

def eliminate(words, letter):
    #Eliminates all words from the list which contain the specified letter
    output = []
    for count in range(0,len(words)):
        word = words[count]
        inthere = False
        for countA in range(0,len(word)):
            if letter == word[countA]:
                inthere = True
        if inthere == False:
            output.append(word)
    return output

def keep(words, letter):
    #Eliminates all words from the list which don't contain this letter
    output = []
    for count in range(0,len(words)):
        word = words[count]
        inthere = False
        for countA in range(0,len(word)):
            if letter == word[countA]:
                inthere = True
        if inthere == True:
            output.append(word)
    return output

def place(words,letter,pos):
    #Eliminates all words which don't have this letter in this position
    output = []
    for count in range(0,len(words)):
        word = words[count]
        if letter == word[pos]:
            output.append(word)
    return output

def letter(words,letter,pos):
    #Eliminates all words with this letter in this position, and all words without the specified letter
    output = []
    for count in range(0,len(words)):
        word = words[count]
        if letter != word[pos]:
            output.append(word)
    output = keep(output,letter)
    return output

def pick(words):
    #returns a random word from the list of words
    guess = "damn"
    if words == []:
        print("No words left to pick from")
    else:
        guess = random.choice(words).strip('\n')
    return guess

words = reset()
guess = ""
while guess != "damn":
    #Will keep on guessing until the keyword 'damn' is detected, which will signal no words left, or some error
    guess = pick(words)
    if guess == "damn":
        break
    print("WORDLE SOLVER GUESSED:\n",guess)
    print("from "+str(len(words))+" possible words")
    #Get colours from Wordle: e = grey (aka eliminate), o = orange, g = green
    user = input(" ")
    if user != "nope":
        greys = []
        oranges = []
        greens = []
        letters = []
        #sort letters by colour
        for count in range(0,len(user)):
            if user[count] == "e":
                greys.append(str(count))
            elif user[count] == "o":
                oranges.append(str(count))
            elif user[count] == "g":
                greens.append(str(count))
            else:
                print("INCORRECT DATA ENTERED!")
                guess = "damn"
        #Dealing with greens
        for count in range(0,len(greens)):
            letters.append(guess[int(greens[count])])
            words = place(words,guess[int(greens[count])],int(greens[count]))
        #Dealing with oranges
        for count in range(0,len(oranges)):
            words = letter(words,guess[int(oranges[count])],int(oranges[count]))
            letters.append(guess[int(oranges[count])])
        #Dealing with greys
        for count in range(0,len(greys)):
            if (guess[int(greys[count])] in letters) == False:
                words = eliminate(words,guess[int(greys[count])])
        if len(greens) == 5:
            print("nice")
            guess = "damn"
    else:
        words.remove(guess+'\n')
