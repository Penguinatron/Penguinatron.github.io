#!/bin/bash
cd "/Users/oliverhagen/Desktop/Software Projects/SSTVFilter" #put your USERNAME in here
sleep 1

read -p "How many .wav files are there? " z

read -p "Start from file number: " y

while [ $y -le $z ]
do
	echo "Playing $y"
	afplay "$y.wav" -v 0.1
	afplay "buffer.wav" -v 1
	sleep 1
	rm "$y.wav"
	sleep 1
	((y++))
	sleep 1
done

echo "Done!"
