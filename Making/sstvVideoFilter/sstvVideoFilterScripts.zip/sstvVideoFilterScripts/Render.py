try:
    import time
    import os
    import numpy as np
    from cv2 import VideoWriter, VideoWriter_fourcc
    import cv2
except: # Block is used to give a nice error message if some libraries aren't installed.
  print("\nYou don't have all of the required libraries to use this programme.")
  print("""This programme requires:
 - time
 - os
 - numpy
 - cv2""")

outputName = "./"+input("Please choose a name for the outputted movie:\n")+".mp4"
FPS = int(input("Please choose a framerate for the outputted movie:\n"))

print("Now rendering...")

files = []
for file in os.listdir():
    if file.endswith(".jpg"):
        files.append(os.path.join("", file))

files.sort()

img = cv2.imread(files[0],1)
height,width,test = img.shape

#print(files)

seconds = int((len(files))/FPS)

fourcc = VideoWriter_fourcc(*'h264')
video = VideoWriter(outputName, fourcc, float(FPS), (width*5, height*5))

t1 = time.time()
t2 = time.time()
tStart = time.time()
count = 0

while count < len(files):
    filename = files[count]
    frame = cv2.imread(filename,1)
    frame = cv2.resize(frame, (width*5, height*5))
    video.write(frame)#Writes a finished frame to the .mp4 file
    t2 = time.time()
    count = count+1
    if t2-t1 >= 2:
        print(str(int(count/len(files)*100))+"%")#Progress updates are always nicer than a 'frozen' screen.
        t1 = time.time()
        t2 = time.time()
    
video.release()#.mp4's done
tEnd = time.time()
print("Done, in "+str(round((tEnd-tStart), 2))+" seconds.")
