#!/bin/bash
cd "/Users/oliverhagen/Desktop/Software Projects/SSTVFilter"
sleep 1

read -p "How many .wav files are there? " z

read -p "Start from file number: " y

while [ $y -le $z ]
do
	echo "Playing $y"
	aplay "$y.wav"
	sleep 1
	rm "$y.wav"
	sleep 1
	((y++))
	sleep 1
done

echo "Done!"
