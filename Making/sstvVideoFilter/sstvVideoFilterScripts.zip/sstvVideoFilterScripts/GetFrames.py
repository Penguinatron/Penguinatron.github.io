import cv2
import numpy as np
import os

filename = input("What is the name of the video file you wish to convert?\n")

# Playing video from file:
cap = cv2.VideoCapture(filename)
count = 0
currentFrame = 0
while(True):
    # Capture frame-by-frame
    ret, frame = cap.read()

    # Saves image of the current frame in jpg file
    name = str(currentFrame) + '.jpg'
    if count%100 == 0:
        print ('Creating...' + name)
        count = 0
    cv2.imwrite(name, frame)
    count = count+1

    # To stop duplicate images
    currentFrame += 1

# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()

print("Done!")
