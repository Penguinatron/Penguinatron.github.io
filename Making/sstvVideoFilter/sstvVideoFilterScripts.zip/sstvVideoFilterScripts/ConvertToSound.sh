#!/bin/bash
cd "/Users/oliverhagen/Desktop/Software Projects/SSTVFilter"
sleep 1
declare -i y=0

echo "Converting images into sound..."

read -p "How many images are there? " z

while [ $y -le $z ]
do
	echo "$y"
	python3 -m pysstv "$y".jpg "$y".wav --mode Robot8BW --resize --keep-aspect-ratio
	rm "$y.jpg"
	((y++))
done

"Done!"